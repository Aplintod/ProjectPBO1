/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pboproject1;

import com.customer.customer;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author HP
 */
public class manajer {
    private static final ArrayList<customer> sesiFoto = new ArrayList<>();
    private static final Scanner scanner = new Scanner(System.in);
    
    public static void tambahSesiFoto() {
        System.out.println("Nama Customer : ");
        String nama = scanner.nextLine();
        System.out.println("Durasi Sesi Foto (15/30/60/90 menit) : ");
        int durasi = scanner.nextInt();
        double harga = durasi * 3000;
        scanner.nextLine();
        
        customer session = new customer(nama, durasi, harga);
        sesiFoto.add(session);
        System.out.println("Sesi Foto Ditambahkan.");
    }
    
    public static void tampilkanSemuaSesi() {
        if (sesiFoto.isEmpty()) {
            System.out.println("Sesi Foto Kosong.");
        } else {
            for (customer session : sesiFoto) {
                session.cetakInvoice();
                System.out.println();
            }
        }
        
    }
    
    public static void ubahStatusPembayaran() {
        System.out.println("Masukkan Nama Pelanggan : ");
        String nama = scanner.nextLine();
        for (customer session :sesiFoto) {
            if (session.getNamaCustomer().equalsIgnoreCase(nama)) {
                session.setStatusPembayaran("Sudah Bayar");
                System.out.println("Status pembayaran untuk" + nama + "telah diubah.");
                return;
            }
        }
        System.out.println("Pelanggan Tidak Ditemukan.");
    }
    
    public static void hapusSesiFoto() {
        System.out.println("Masukkan Nama Customer : ");
        String nama = scanner.nextLine();
        for (int i = 0; i < sesiFoto.size(); i++) {
            if (sesiFoto.get(i).getNamaCustomer().equalsIgnoreCase(nama)) {
                sesiFoto.remove(i);
                System.out.println("Sesi Foto untuk" + nama + "telah dihapus.");
                return;
            }
        }
        System.out.println("Customer Tidak Ditemukan.");
    }
    
}
