/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.customer;

/**
 *
 * @author HP
 */
public class customer {
    private final String namaCustomer; //Ini dihint ganti final jadi saya ganti saja :)
    private final int durasi;
    private final double harga;
    private String statusPembayaran;
    
    public customer(String namaCustomer, int durasi, double harga) {
        this.namaCustomer = namaCustomer;
        this.durasi = durasi;
        this.harga = harga;
        this.statusPembayaran = "Belum Bayar";
    }
    
    public void cetakInvoice() {
            System.out.println("Nama Customer : " + namaCustomer);
            System.out.println("Durasi Sesi Foto : " + durasi + " menit");
            System.out.println("Total Harga : " + harga);
            System.out.println("Status Pembayaran : " + statusPembayaran);
    }
    
    public String getNamaCustomer() {
        return namaCustomer;
    }
    
    public void setStatusPembayaran(String statusPembayaran) {
        this.statusPembayaran = statusPembayaran;
    }
}
